'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Package extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Package.init({
    trackingNumber: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        len: [10,10],
        isNumeric: true
      }
    },
    weightKg: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 2,
        max: 80
      }
    },
    sender: {
      type: DataTypes.STRING,
      allowNull: true
    },
    recipient: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        has2names(value) {
          const names = value.split(' ');
          if (names.length !== 2) {
            throw new Error('Recipient must have a first and last name');
          }
        }
      }
    },
    isDelivered: {
      type: DataTypes.BOOLEAN,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Package',
  });
  return Package;
};
