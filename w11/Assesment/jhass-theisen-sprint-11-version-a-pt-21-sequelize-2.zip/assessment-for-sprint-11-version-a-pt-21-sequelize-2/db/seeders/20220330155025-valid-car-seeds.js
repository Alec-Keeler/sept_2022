'use strict';

const { Car } = require('../models');

// DON'T SPEND ALL YOUR TIME MAKING REAL SEED DATA!!!
// Try to just spend only 5 minutes to create the seed data for testing
// You do not need to put in real car data as values! The data values
  // just need to make sense based from the migration and model files.

const validCars = [
  // Your code here
  {
    make: 'TOYOTA',
    model: 'Corolla',
    modelYear: 1999,
    bodyStyle: 'COMPACT',
    trimLevel: 'Medium',
    milesPerGallon: 20,
    powertrain: 'gas',
    isAutomatic: false,
  },
  {
    make: 'HYUNDAI',
    model: 'Accent',
    modelYear: 2009,
    bodyStyle: 'LOW RIDER',
    trimLevel: 'Low',
    milesPerGallon: 40,
    powertrain: 'gas',
    isAutomatic: true,
  },
  {
    make: 'TESLA',
    model: 'Model 3',
    modelYear: 2020,
    bodyStyle: 'COMPACT',
    trimLevel: 'Low',
    milesPerGallon: null,
    powertrain: 'electric',
    isAutomatic: true,
  },

];

module.exports = {
  async up (queryInterface, Sequelize) {
    try {
      await Car.bulkCreate(validCars, {
        validate: true,
      });
    } catch (err) {
      console.log(err);
      throw err;
    }
  },

  async down (queryInterface, Sequelize) {
    for (let carInfo of validCars) {
      try {
        await Car.destroy({
          where: carInfo
        });
      } catch (err) {
        console.log(err);
        throw err;
      }
    }
  },
  // DO NOT MODIFY BELOW (for testing purposes):
  validCars,
};
