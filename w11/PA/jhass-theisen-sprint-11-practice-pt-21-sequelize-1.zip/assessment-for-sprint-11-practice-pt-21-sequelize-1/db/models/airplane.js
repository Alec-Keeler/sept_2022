'use strict';
const {
  Model, HostNotFoundError
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Airplane extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Airplane.init({
    flightNumber: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
      validate: {
        isUppercase: true,
        len: [3,6],
        validFormat(value) {
          const chars = value.split('');
          const firstTwo = chars.slice(0,2);
          const restOfChars = chars.slice(2);
          for (let char of firstTwo) {
            // if is integer, upper vs lower will be same
            if (char.toUpperCase() === char.toLowerCase()) {
              throw new Error('first two chars must be letters');
            }
          }

          for (let char of restOfChars) {
            if (isNaN(char)) {
              throw new Error('All characters after the first two must be numbers');
            }
          }
        }
      }
    },
    model: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [3,6]
      }
    },
    inService: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    homeBase: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        isAlpha: true,
        len: [3,3],
        isUppercase: true
      },
    },
    maxNumPassengers: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 2,
        max: 853,
      }
    },
    currentNumPassengers: {
      type: DataTypes.INTEGER,
      validate: {
        min: 0,
        max: 853,
        lessThanMax(value) {
          if (parseInt(value) > parseInt(this.maxNumPassengers)) {
            throw new Error('Current Num Passengers cannot be greater than Max Num Passengers');
          }
        }
      },
    },
    cruisingAltitudeFt: {
      type: DataTypes.INTEGER,
      validate: {
        min: 500,
        max: 41000
      }
    },
    firstFlightDate:{
      type: DataTypes.DATE,
      validate: {
        isAfter: '2019-12-31',
        isBefore: '2022-01-01'
      }
    },
  }, {
    sequelize,
    modelName: 'Airplane',
  });
  return Airplane;
};
